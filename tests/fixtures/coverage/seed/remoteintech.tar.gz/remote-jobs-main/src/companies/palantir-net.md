---
title: "Palantir.net"
slug: palantir-net
website: https://www.palantir.net/
careers_url: https://palantir.bamboohr.com/careers
region: americas
remote_policy: remote-friendly
company_size: small
technologies:
  - php
addedAt: 2017-07-27
updatedAt: 2018-04-16
---

## Company blurb

Palantir® is a full-service web agency that works to strengthen humanity by helping others discover, create, and share knowledge.

## Company size

Approximately 40 individuals.

## Remote status

Full distributed with a "remote outpost" in Evanston, Illinois (just outside of Chicago). Employees should try to overlap with at least six hours between 9am to 6pm CST. Team communicates via Hipchat, Google Hangouts, Zoom and e-mail. A week long, in-person retreat occurs once a year.

## Region

US only.

## Company technologies

- Drupal

## Office locations

**Remote Outpost**

622 Davis Street<br />
Suite 400<br />
Evanston, IL 60201<br />
773.645.4100

## How to apply

Ongoing application: https://palantir.bamboohr.com/careers

Specific job openings are posted when required. General disciplines include front end developers, Drupal developers, designers and user interface designers, web strategists and project managers.
