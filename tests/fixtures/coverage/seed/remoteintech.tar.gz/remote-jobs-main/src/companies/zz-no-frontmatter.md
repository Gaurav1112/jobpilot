# Just notes

No frontmatter here.
