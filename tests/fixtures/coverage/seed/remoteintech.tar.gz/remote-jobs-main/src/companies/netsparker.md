---
title: "Netsparker"
slug: netsparker
website: https://www.netsparker.com/
careers_url: https://www.netsparker.com/jobs/
region: worldwide
remote_policy: fully-remote
company_size: small
technologies:
  - dotnet
addedAt: 2015-12-11
updatedAt: 2018-04-16
---

## Company blurb

We are a small company with great technical skills and a passion for web application security. We are currently developing one of the most innovative security scanners in the market, used by thousands around the world, including an impressive list of leading companies and government agencies.

Although the company is based in London (UK), its entire workforce is virtual, with team members around the world using the latest tools and techniques to contribute, collaborate and get their jobs done.

To keep it real, we meet up occasionally (most recently in Istanbul) but, for the most part, we prefer to sidestep the outdated rituals of old-school business. We have no dress code or fixed working hours and we don’t suffer from micro-management; just a shared determination to make our product better and to satisfy the needs of our enthusiastic customer base.

Every aspect of our business operates within an agile results-driven “startup” mindset. We exchange information freely within our team and encourage every member to take risks that will give us an edge on our competition.

## Company size

18 employees listed on the [about page](https://www.netsparker.com/about/)

## Remote status

We are a fully distributed team. We communicate through Flowdock, Skype, and e-mail.

## Region

Worldwide

## Company technologies

.NET Framework, Winforms

## Office locations

- London, UK
- USA
- Istanbul, Turkey

## How to apply

[Career Opportunities at Netsparker] (https://www.netsparker.com/jobs/)
