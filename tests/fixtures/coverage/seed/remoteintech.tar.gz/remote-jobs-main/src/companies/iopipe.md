---
title: "IOpipe"
slug: iopipe
website: https://www.iopipe.com
careers_url: https://angel.co/iopipe
region: other
remote_policy: remote-friendly
company_size: tiny
technologies:
  - cloud
  - go
  - java
  - javascript
  - python
addedAt: 2018-04-20
updatedAt: 2018-04-20
---

## Company blurb

IOpipe is the serverless DevOps platform built for teams building and running event-driven architectures in AWS Lambda. We're focused on what we can do for our customers running serverless architectures to make their lives easier and their software more reliable.

## Company size

10 and growing.

## Remote status

IOpipe is a distributed company, with no central office. A fair number of employees are located in the Philadelphia region, but do not maintain an office, albeit some work out of the same co-working space.

## Region

All employees are US-based.

## Company technologies

NodeJS/JavaScript, Python, Java, Golang. We're heavy AWS users (Kinesis, AWS Lambda [of course], and other AWS services).

## Office locations

N/A

## How to apply

[Open positions](https://angel.co/iopipe)

Additionally, we're always listening at hiring@iopipe.com
