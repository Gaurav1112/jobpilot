---
title: Epsilon Freight
website: https://epsilon.test
careers_url: https://epsilon.wd5.myworkdayjobs.com/External
---

## Company blurb

A fictional company for the coverage e2e test.
