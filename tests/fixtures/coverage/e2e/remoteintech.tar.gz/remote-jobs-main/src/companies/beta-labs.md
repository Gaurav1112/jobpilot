---
title: Beta Labs
website: https://beta.test
careers_url: https://beta.test/jobs
---

## Company blurb

A fictional company for the coverage e2e test.
