---
title: Yankee Works
website: https://yankee.test
---

## Company blurb

A fictional company with no careers page, for the listed-ATS coverage test.
